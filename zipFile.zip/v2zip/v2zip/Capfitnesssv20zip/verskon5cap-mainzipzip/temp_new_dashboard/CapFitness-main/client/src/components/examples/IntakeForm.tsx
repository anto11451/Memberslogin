import IntakeForm from '../IntakeForm';

export default function IntakeFormExample() {
  return <IntakeForm />;
}
